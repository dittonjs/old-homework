﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4AbstractClasses
{
    public interface IAreaAndVol
    {
        double getArea();
        double getVolume();
    }
}
