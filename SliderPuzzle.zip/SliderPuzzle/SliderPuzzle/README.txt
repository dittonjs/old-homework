-- PLEASE FOLLOW THESE INSTRUCTIONS

1. Run the program
2. The program will ask you if you want to do a random board or enter your own board.
	a. If you choose random board it will prompt you to enter the number of moves you want to jumble the board by.
	b. If you elect to enter your own board, enter the nnumbers one by one in the order you want them to be in the board (row by row)
3. The program will show the initial board, 
4. Wait for the program to finish running, the hardest puzzles will take at most 30 seconds.
-- WARNING if you entered you own puzzle and it is unsolvalble, the program will run forever. If the program takes more than 2 min to run
   then you should quit the program using ctrl-c.
5. Once the program is finished inspect the solution.
6. The program will ask you if you want to play again, enter 'y' for yes and 'n' for no.