#include "Game.h"
#include <iostream>

// takes a board and sets inserts it at the end of the queue
void Game::insert(Board *board){
	if (head == NULL){
		head = board;
		tail = board;
		size++;
		return;
	}

	Board * temp = tail;
	temp->next = board;
	temp->next->previous = temp;
	tail = temp->next;
	size++;
}

// removes the first board from the list
void Game::remove(){
	Board *temp = this->head;
	head = temp->next;
	head->previous = NULL;
	removedCount++;
	delete temp;
}

// removes all boards from the queue
void Game::removeAll(){
	if (head == NULL) return;
	Board *temp = head;
	while (temp->next != NULL){
		Board *toDelete = temp;
		temp = temp->next;
		delete toDelete;
	}
	head = NULL;
	tail = NULL;
	removedCount = 0;
	size = 0;
}
