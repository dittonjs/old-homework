// SliderProject.cpp : Defines the entry point for the console application.
//



#include "Game.h"   // You need to create your own game class
#include <time.h>
#include <iostream> //for some reason i get a cout is ambiguous error if i leave this in.
#include <string>
#include <sstream>
#include "Board.h"

const int SIZE = 3;       // Dimension of board
using namespace std;
int main()
{
	srand((int)time(NULL));
	
	// create the game
	Game *game = new Game();
	bool done = false;
	while (!done){
		
		// create the board
		bool solved = false;
		Board *board = new Board();
		cout << "[1] Random board" << endl;
		cout << "[2] Make your own board" << endl;
		cout << "Enter the number of your choice" << endl;
		int choice;
		cin >> choice;
		
		// setup random board
		if (choice != 2){
			cout << "How difficult would you like the board to be?" << endl;
			cout << "Enter a number 1 - 50" << endl;
			int seed;
			cin >> seed;
			board->makeBoard(seed);
		}
		// get user input and use their board
		else {
			cout << "Enter numbers 0-8 in the order you would like them to be on the board" << endl;
			cout << "WARNING: If the sequence of numbers is unsolvable the game will continue " << endl;
			cout << "until you explicitly tell the program to stop." << endl;
			cout << "Enter each number 1 by 1, pushing enter between each number";
			int nums[9];
			for (int i = 0; i < 9; i++){
				cout << "Enter a number then press enter, keep track of the numbers you have entered." << endl;
				cin >> nums[i];
			}
			board->makeBoard(nums);
		}
		
		// erase the moves used to create the board
		board->clearMoves();

		// store a copy of the original board for later;
		Board *copy = new Board(*board);

		// insert the first board into the game
		game->insert(board);
		Board * finalBoard = NULL;
		cout << "first board: " << endl;
		cout << board->toString() << endl;

		while (!solved){
			// we set game back to new head because we delete the old one.
			for (Board *temp = game->head; temp != NULL; temp = game->head){
				// check the board to see if its solved
				solved = temp->checkSolution();
				if (solved) {
					finalBoard = temp;
					break;
				}
				else {
					// if board is not the solution the get all the possible next boards from the current one.
					Board *nextBoard1 = temp->getNextBoard(temp, 'U');
					Board *nextBoard2 = temp->getNextBoard(temp, 'D');
					Board *nextBoard3 = temp->getNextBoard(temp, 'L');
					Board *nextBoard4 = temp->getNextBoard(temp, 'R');

					if (nextBoard1 != NULL){
						game->insert(nextBoard1);
					}
					if (nextBoard2 != NULL){
						game->insert(nextBoard2);
					}
					if (nextBoard3 != NULL){
						game->insert(nextBoard3);
					}
					if (nextBoard4 != NULL){
						game->insert(nextBoard4);
					}
					// remove the current board because its not the solution
					game->remove();
				}
			}

			// make sure we didnt mess up and get a null final board
			if (finalBoard != NULL){

				// use the copy of the original board to show the moves to get the final board.
				copy->showMe(finalBoard->moves);
				cout << "MOVES TO REACH: " << finalBoard->moves << endl;
				cout << finalBoard->toString() << endl;
				cout << "TOTAL BOARDS ADDED: " << game->size << endl;
				cout << "BOARDS REMOVED FROM THE QUEUE: " << game->removedCount << endl;
			}

			// empty the queue of all remaining boards
			game->removeAll();
			
			// clean up for another game or for end of program.
			delete copy;
			cout << "Go Again?? [y][n]" << endl;
			char answer;
			cin >> answer;
			if (answer == 'n'){
				delete game;
				done = true;
			}
		}
	}
}