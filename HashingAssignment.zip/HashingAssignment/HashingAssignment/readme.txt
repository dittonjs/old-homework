To run this program open the solution in visual studios and hit ctrl-f5.
Change the global variables at the top to change how much of what information is displayed.
