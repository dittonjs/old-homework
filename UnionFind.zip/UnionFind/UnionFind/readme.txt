To run the program open the solution in visual studios and click run.
The home work said to answer the following questions about runtime and memory in 
this file but there are no questions mentioned in the homework description.